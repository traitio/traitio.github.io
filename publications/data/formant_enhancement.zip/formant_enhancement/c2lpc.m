function a = c2lpc(c,p)
%C2LPC CONVERT CEPSTRUM TO LPC
%   A = C2LPC(C,P) convert cepstrum to LPC coefficients.
%
% Input:
%   c      - Cepstrum
%   p      - Order of desired LPC
%
% Output:
%   a      - LPC coefficients
%
% Reference:
%
% J.D. Markel and A.H. Gray, Jr., Linear prediction of speech,
% Springer-Verlag, New York, NY, 1976.
%
% Tuomo Raitio, 10.07.2013

% Initialize
a = zeros(1,p);  % Initialize LPC to zeros
c = c(2:end);    % Omit first term

% Start recursion
for n = 1:p
    if n == 1
        a(n) = -c(n);
    else
        tmp = 0;
        for k = 1:n-1
            tmp = tmp + ((n-k)/n)*c(n-k)*a(k);
        end
        a(n) = -c(n) - tmp;
    end
end
a = [1 a];
