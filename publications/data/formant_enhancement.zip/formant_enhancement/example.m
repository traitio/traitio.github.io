% Demo script on applying formant enhancement
%
% Required files:
%  - fe_lpc.m	 (LPC-based formant enhancement)
%  - fe_lsf.m	 (LSF-based formant enhancement)
%  - fe_zscale.m (unit circly scale enhancement)
%  - fe_cepst.m  (cepstrum based enhancement)
%  - lpc2c.m     (conversion from LPC to cepstrum)
%  - c2lpc.m     (conversion from cepstrum to LPC)
%  - speech.wav (speech file)
%
% Reference:
%
% T. Raitio, A. Suni, H. Pulakka, M. Vainio, and P. Alku, "Comparison of
% Formant Enhancement Methods for HMM-Based Speech Synthesis", in 7th ISCA
% Speech Synthesis Workshop (SSW7), Kyoto, Japan, 2010, pp. 334-339.
%
% Tuomo Raitio, 06.07.2012
% Updated 10.07.2013

clc
clear
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Define formant enhancement method.
% Choose between LPC/LSF/Zscale/Cepst.
fe_method = 'LPC';

%%% LPC
% Define the strength of the LPC-based enhancement. Gamma must be between
% ]0,1[. Smaller gamma will result in stronger enhancement. Delta defines
% the unmodified area within spectral peaks.
gamma = 0.6;     
delta = 200; % Hz

%%% LSF
% Define the strength of the LSF-based enhancement. Alpha must be between
% ]0,1[. Smaller alpha will result in stronger enhancement.
alpha = 0.8;

%%% Zscale
% Define the amount of unit circle scaling. Scale must be greater than
% zero. The tuning of the scale is very sensitive; too much scaling will
% results in oversharp formants. A value of 0.99 will result in adequate
% results. Alternatively, a scale greater than 1 can be set to de-emphasize
% formants.
scale = 0.99;

%%% Cepst
% Convert LPC coefficients to cepstrum, and modify cepstrum by multiplying
% the cepstral coefficients that represent (mostly) the formant structure
% (3...n) by a positive coefficient k (k > 1 for enhancement).
% Alternatively, a scale less than 1 can be set to de-emphasize formants.
k = 1.05;

% Define other parameters
p = 20;        % LPC analysis order
win = 25;      % Window length (ms)
shift = 10;    % Window shift (ms)
nfft = 1024;   % FFT length

% Options for plotting
plot_framewise_spectra = 0;
plot_signals = 1;
play_signals = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Read speech file
[x,fs] = wavread('speech.wav');

% Apply constant pre-emphasis (optional)
xe = filter([1 -0.68],1,x);

% Evaluate the number of samples for window and shift
N = round(win/1000*fs);
Ns = round(shift/1000*fs);

% Initialize enhanced speech vector
x_enh = zeros(size(xe));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Start enhancement frame by frame
ind = 0;
while(ind*Ns+N <= length(x))

    % Get frame and preframe for smooth filtering
    frame = xe(ind*Ns+1:ind*Ns+N);
    if ind*Ns+1-p > 1
        preframe = xe(ind*Ns-2*p:ind*Ns);
    else
        preframe = linspace(-frame(1),frame(1),2*p+1)';
    end

    % LPC, filter out formants to get residual
    a = lpc(frame.*blackman(N),p);
    residual = filter(a,1,[preframe ; frame]);

    % Choose formant enhancement method
    switch fe_method
        case 'LPC'
            a_enh = fe_lpc(a,gamma,delta,fs);
        case 'LSF'
            a_enh = fe_lsf(a,alpha);
        case 'Zscale'
            a_enh = fe_zscale(a,scale);
        case 'Cepst'
            a_enh = fe_cepst(a,k);
        otherwise
            disp(['Unknown method ''' fe_method '''']);
            return
    end
    
    % Plot original and enhanced spectra (optional)
    if plot_framewise_spectra == 1
        figure(1)
        clf;
        [h,w] = freqz(1,a,nfft,fs);
        h_enh = freqz(1,a_enh,nfft,fs);
        plot(w,db(h))
        hold on
        plot(w,db(h_enh),'r')
        axis([0 fs/2 -50 50])
        legend('Original','Enhanced')
        xlabel('Frequency (Hz)')
        ylabel('Magnitude (dB)')
        title('Spectrum')
        pause
    end
    
    % Filter residual with enhanced formant structure
    frame_enh = filter(1,a_enh,residual);
    frame_enh = frame_enh(2*p+2:end);
    
    % Scale frame energy
    frame_enh = frame_enh*sqrt(sum(frame.^2)/sum(frame_enh.^2));

    % Overlap-add enhanced frame
    x_enh(ind*Ns+1:ind*Ns+N) = x_enh(ind*Ns+1:ind*Ns+N) + ...
        frame_enh.*blackman(N);
    
    % Increment index
    ind = ind + 1;
end

% Remove pre-emphasis (optional)
x_enh = filter(1,[1 -0.68],x_enh);

% Plot signals
if plot_signals == 1
    figure(2)
    plot(x)
    hold on
    plot(x_enh,'r')
    axis([1 length(x) min([x ; x_enh]) max([x ; x_enh])]);
    ylabel('Amplitude')
    xlabel('Time (samples)')
    legend('Original','Enhanced')
end

% Play signals
if play_signals == 1
	soundsc(x,fs)
    soundsc(x_enh,fs)
end