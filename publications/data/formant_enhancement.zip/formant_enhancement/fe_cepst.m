function a_enh = fe_cepst(a,k)
%FE_CEPST CEPSTRUM BASED FORMANT ENHANCEMENT
%   A_ENH = FE_CEPST(A,SCALE) enhances the formants of LPC coefficients in
%   the cepstral domain.
%
%   a      - LPC coefficients
%   scale  - Srength of the enhancement
%   a_enh  - Enhanced LPC coefficients
%
% References:
%
% D. Cole and S. Sridharan, "Speech Enhancement by Formant Sharpening in
% the Cepstral Domain", in Proceedings of the 9th Australian International
% Conference on Speech Science & Technology, Melbourne, December 2-5, 2002,
% pp. 244-249.
%
% Tuomo Raitio, 10.07.2013

% Sanity check
if k <= 0
    disp('Error: k must be greater than 0');
    a_enh = a;
    return;
end

% Evaluate cepstrum from LPC coefficients
c = lpc2c(a,length(a));

% Modify cepstrum by multiplying the cepstral coefficients that represent
% most of the formant structure (3...n) by a positive coefficient k (k > 1
% for enhancement)
c(3:end) = c(3:end)*k;

% Reconstruct LPC coefficients from modified cepstrum
a_enh = c2lpc(c,length(a)-1);
