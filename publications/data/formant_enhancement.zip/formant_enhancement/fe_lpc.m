function a_enh = fe_lpc(a,gamma,delta,fs)
%FE_LPC LPC-BASED FORMANT ENHANCEMENT
%   A_ENH = FE_LPC(A,GAMMA,DELTA,FS) enhances the formants of the all-pole
% spectral model of speech by modifying the power spectrum of LPC and then
% re-estimating LPC coefficients.
%
%   a      - LPC coefficients
%   gamma  - Srength of the enhancement. Gamma must be between ]0,1[. The
%            smaller gamma is, the stronger the enhancement will be
%   delta  - The width of the unmodified part of spectral peaks in Hz
%   fs     - Sampling frequency
%   a_enh  - Enhanced LPC coefficients
%
% Reference:
%
% T. Raitio, A. Suni, H. Pulakka, M. Vainio, and P. Alku, "Comparison of
% Formant Enhancement Methods for HMM-Based Speech Synthesis", in 7th ISCA
% Speech Synthesis Workshop (SSW7), Kyoto, Japan, 2010, pp. 334-339.
%
% Tuomo Raitio, 05.07.2012

% Sanity check for gamma
if gamma <= 0 || gamma >= 1
    disp('Error: gamma must be between ]0,1[.');
    a_enh = a;
    return;
end

% Sanity check for delta
if delta <= 0
    disp('Error: delta must be greater than zero.');
    a_enh = a;
    return;
end

% Evaluate power spectrum
nfft = 4*1024;
s = abs(fft(1,nfft)./fft(a,nfft));
s = s(1:nfft/2+1);

% Find formant peaks by differentiating and finding zero-crossings
ds = diff(s);
ind = 1;
for i = 1:length(ds)-1
    if ds(i) >= 0 && ds(i+1) <= 0
        f(ind) = i;
        ind = ind + 1;
    end
end

% Modify power spectrum by reducing energy from the valleys
w = round(delta/fs*nfft/2);
for i = 1:length(f)-1 % Between formants
    for j = f(i)+w:f(i+1)-w
        s(j) = s(j)*gamma;
    end
end
for i = 1:f(1)-w % Between zero and first formant
    s(i) = s(i)*gamma;
end
for i = f(end)+w:length(s) % Between last formant and fs/2
    s(i) = s(i)*gamma;
end

% Reconstruct image spectrum and evaluate autocorrelation
s = [s fliplr(s(2:end-1))];
ac = ifft(s.^2);

% Evaluate LPC from autocorrelation
a_enh = levinson(ac,length(a)-1);










