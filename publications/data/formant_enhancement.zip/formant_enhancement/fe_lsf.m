function a_enh = fe_lsf(a,alpha)
%FE_LSF LSF-BASED FORMANT ENHANCEMENT
%   A_ENH = FE_LSF(A,ALPHA) enhances the formants of the all-pole spectral
% model of speech by modifying distances between LSFs.
%
%   a      - LPC coefficients
%   alpha  - Srength of the enhancement. Alpha must be between ]0,1]. The
%            smaller alpha is, the stronger the enhancement will be.
%   a_enh  - Enhanced LPC coefficients
%
% References:
%
% Z.-H. Ling, Y. Wu, Y.-P. Wang, L. Qin, and R.-H. Wang, "USTC system for
% Blizzard Challenge 2006: an improved HMM-based speech synthesis method",
% in Blizzard Challenge Workshop, 2006.
%
% T. Raitio, A. Suni, H. Pulakka, M. Vainio, and P. Alku, "Comparison of
% Formant Enhancement Methods for HMM-Based Speech Synthesis", in 7th ISCA
% Speech Synthesis Workshop (SSW7), Kyoto, Japan, 2010, pp. 334-339.
%
% Tuomo Raitio, 05.07.2012, 10.7.2013

% Sanity check
if alpha <= 0 || alpha >= 1
    disp('Error: alpha must be between ]0,1[.');
    a_enh = a;
    return;
end

% Convert LPC coefficients to line spectral frequencies (LSFs)
lsf = poly2lsf(a);

% LSF-based enhancement
for i = 1:length(lsf)-1
    d(i) = alpha*(lsf(i+1) - lsf(i));
    if i > 1
        lsf(i) = lsf(i-1) + d(i-1) + (d(i-1)^2)/(d(i-1)^2 + d(i)^2)*((lsf(i+1)-lsf(i-1))-(d(i)+d(i-1)));
    end
end

% Convert LSFs back to LPC
a_enh = lsf2poly(lsf);
