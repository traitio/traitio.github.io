function a_enh = fe_zscale(a,scale)
%FE_ZSCALE UNIT CIRCLE SCALING BASED FORMANT ENHANCEMENT
%   A_ENH = FE_ZSCALE(A,SCALE) enhances the formants of the all-pole
%   spectral model of speech by scaling the unit circle.
%
%   a      - LPC coefficients
%   scale  - Srength of the enhancement. Scale must be greater than zero.
%            If alpha is between ]0,1[, the smaller alpha is, the stronger
%            the enhancement will be. If alpha > 1, the formants will
%            become less prominent.
%   a_enh  - Enhanced LPC coefficients
%
% References:
%
% A. Schaub and P. Straub, "Spectral sharpening for speech enhancement/
% noise reduction", in International Conference on Acoustics, Speech, and
% Signal Processing (ICASSP), 1991, pp. 993,996 vol.2, 14-17 Apr 1991
%
% Tuomo Raitio, 10.07.2013

% Sanity check
if scale <= 0
    disp('Error: scale must be greater than 0');
    a_enh = a;
    return;
end

% Formant enhancement
a_enh = zeros(size(a));
for i = 1:length(a)
    a_enh(i) = a(i)/scale^(i-1);
end