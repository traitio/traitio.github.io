function c = lpc2c(a,N)
%LPC2C CONVERT LPC TO CEPSTRUM
%   C = LPC2C(A,N) convert LPC coefficients to cepstrum of length N using
%   a recursive relation between LPC and cepstrum.
%
% Input:
%   a      - LPC coefficients
%   n      - Order of cepstrum
%
% Output:
%   c      - Output cepstrum
%
% Reference:
%
% J.D. Markel and A.H. Gray, Jr., Linear prediction of speech,
% Springer-Verlag, New York, NY, 1976.
%
% Tuomo Raitio, 10.07.2013

% Initialize
a = a(2:end);      % Take the LPC coefficients
p = length(a);     % All-pole order
c = zeros(1,N-1);  % Initialize cepstrum to zeros

% Start recursion
for n = 1:N-1
    if n == 1
        c(n) = -a(n);
    elseif n > 1 && n <= p
        tmp = 0;
        for k = 1:n-1
            tmp = tmp + ((n-k)/n)*c(n-k)*a(k);
        end
        c(n) = -a(n) - tmp;
    else
        tmp = 0;
        for k = 1:p
            tmp = tmp + ((n-k)/n)*c(n-k)*a(k);
        end
        c(n) = -tmp;
    end
end
c = [0 c];