% Demo script on how to use iterative adaptive inverse filtering (IAIF)
%
% Required files:
%  - iaif.m         (IAIF glottal inverse filtering)
%  - syn_speech.wav (synthetic speech file)
%  - syn_exc.wav    (synthetic excitation of the speech file)
%
% Tuomo Raitio, 12.8.2012
% Revised, Tuomo Raitio, 10.07.2013

function example_with_synthetic_speech()

clc
clear
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Options for plotting
plot_framewise = 1;
plot_final = 1;

% Read speech file. The speech file is created synthetically in order to
% enable the comparison of estimated and original excitations.
[x,fs] = wavread('syn_speech.wav');

% Read the excitation of the synthetic speech file for reference
e = wavread('syn_exc.wav');

% Define parameters
p_vt = round(fs/1000+4);    % LPC analysis order
p_gl = round(fs/2000);      % LPC analysis order for the glottal source
d = 0.99;                   % Leaky integrator (values between [0.9,1])
hpfilt = 0;                 % No high pass filtering inside IAIF method
win = 30;                   % Window length (milliseconds)
shift = 2;                  % Window shift (milliseconds)
Fstop = 40;                 % Stopband Frequency
Fpass = 70;                 % Passband Frequency
Nfir = round(300/16000*fs); % FIR numerator order
nfft = 1024;                % FFT length

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% High-pass filter speech in order to remove possible low frequency
% fluctuations. Signal is shifted to compensate the long delay due to
% filtering. As filtering is done here, there is no need to apply filtering
% inside the IAIF method.
if mod(Nfir,2) == 1
    Nfir = Nfir + 1;
end
B = hpfilter_fir(Fstop,Fpass,fs,Nfir);
x = [x ; zeros(round(length(B)/2)-1,1)];
x = filter(B,1,x);
x = x(round(length(B)/2):end);

% Evaluate the number of samples for window and shift
N = round(win/1000*fs);
Nshift = round(shift/1000*fs);

% Allocate source vector
source = zeros(size(x));

% Figure
scrsz = get(0,'ScreenSize');
if plot_framewise == 1
    figure('Position',[scrsz(3)/4 scrsz(4)/20 800 1000])
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Start analysis frame by frame
ind = 0;
while(ind*Nshift+N <= length(x))
    
    % Get frames
    frame = x(ind*Nshift+1:ind*Nshift+N);
    exc = e(ind*Nshift+1:ind*Nshift+N);

    % Glottal inverse filtering using IAIF
    [g,dg,a] = iaif(frame,fs,p_vt,p_gl,d,hpfilt);

    % Scale source energy
    dg = dg*sqrt(sum(exc(40:end).^2)/sum(dg(40:end).^2));
    
    % Plot estimated vocal tract spectrum
    if plot_framewise == 1
        [h,w] = freqz(1,a,nfft,fs);
        clf
        subplot(5,1,1)
        plot(w,db(h),'r')
        axis([0 fs/2 -23 30])
        title('Estimated vocal tract filter')
        ylabel('Magnitude (dB)')
        xlabel('Frequency (Hz)')

        % Plot synthetic speech signal
        subplot(5,1,2)
        plot(frame)
        axis([40 length(dg) -1 1])
        set(gca,'XTick',fs/1000*[0 5 10 15 20 25 30 35 40]);
        set(gca,'XTickLabel',[0 5 10 15 20 25 30 35 40]);
        ylabel('Amplitude')
        xlabel('Time (ms)')
        title('Speech signal')
        text(N/2.5,-12.3,'Press any key to go to next frame')

        % Plot estimated glottal flow and integrated original excitation
        subplot(5,1,3)
        plot(g)
        hold on
        plot(filter(1,[1 -d],exc),'r')
        axis([40 length(dg) -1.2 1.2])
        set(gca,'XTick',fs/1000*[0 5 10 15 20 25 30 35 40]);
        set(gca,'XTickLabel',[0 5 10 15 20 25 30 35 40]);
        ylabel('Amplitude')
        xlabel('Time (ms)')
        title('Glottal flow')

        % Plot estimated glottal flow derivative and original excitation
        subplot(5,1,4)
        plot(dg)
        hold on
        plot(exc,'r')
        axis([40 length(dg) -0.1 0.1])
        set(gca,'XTick',fs/1000*[0 5 10 15 20 25 30 35 40]);
        set(gca,'XTickLabel',[0 5 10 15 20 25 30 35 40]);
        ylabel('Amplitude')
        xlabel('Time (ms)')
        title('Glottal flow derivative')

        % Plot spectra of the estimated glottal flow and original excitation
        subplot(5,1,5)
        Pdg = db(abs(fft(dg.*hann(length(dg)),2*nfft)));
        Pexc = db(abs(fft(exc.*hann(length(exc)),2*nfft)));
        Pdg = Pdg(1:nfft);
        Pexc = Pexc(1:nfft);
        plot(w,Pdg)
        hold on
        plot(w,Pexc,'r')
        axis([0 fs/2 -60 20])
        ylabel('Magnitude (dB)')
        xlabel('Frequency (Hz)')
        title('Glottal flow spectrum')
        legend('Estimated','Original')
        pause
    end
    
     % Overlap-add voice source
    source(ind*Nshift+1:ind*Nshift+N) = ...
        source(ind*Nshift+1:ind*Nshift+N) + dg.*hanning(N)/(win/shift/2);
    
    % Increment index
    ind = ind + 1;
end

% Plot signals
if plot_final == 1
    figure('Position',[scrsz(3)/4 scrsz(4)/4 1000 500])
    
    l(1) = subplot(2,1,1);
    plot(x)
    axis([1 length(x) min(x)-0.1 max(x)+0.1])
    set(gca,'XTick',fs/1000*(0:50:length(x)/fs*1000));
    set(gca,'XTickLabel',0:50:length(x)/fs*1000);
    ylabel('Amplitude')
    xlabel('Time (ms)')
    title('Speech signal')
    
    l(2) = subplot(2,1,2);
    plot(e)
    hold on
    plot(source,'r')
    axis([1 length(source) min(source)-0.05 max(source)+0.05])
    set(gca,'XTick',fs/1000*(0:50:length(x)/fs*1000));
    set(gca,'XTickLabel',0:50:length(x)/fs*1000);
    ylabel('Amplitude')
    xlabel('Time (ms)')
    title('Estimated glottal flow derivative signal')
    legend('Original excitation','Estimated excitation')
    linkaxes(l,'x')
end





function B = hpfilter_fir(Fstop,Fpass,fs,N)
% FIR least-squares Highpass filter design using the FIRLS function
%
% Tuomo Raitio
% 10.7.2012

% Calculate the coefficients using the FIRLS function.
b  = firls(N, [0 Fstop Fpass fs/2]/(fs/2), [0 0 1 1], [1 1]);
Hd = dfilt.dffir(b);

% Save to B
B = Hd.Numerator;

