% Example on using glottal inverse filtering and autocorrelation based
% pitch detection.
%
% Required files:
%
% - get_pitch.m     (main file for pitch detection)
% - f0det.m         (autocorrelation based f0 detection)
% - iaif.nm         (glottal inverse filtering)
%
% - mv_0002.wav
%
% Tuomo Raitio
% 12.8.2012

function example_pitch_detection()

clc
clear
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Speech file name
speechfile = 'mv_0002.wav';

% Frame shift (ms)
shift = 10;

% Minimum and maximum F0
use_predefined_f0_limits = 0;
fmin = 50;
fmax = 500;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Read speech file
[s,fs] = wavread(speechfile);

% Get pitch
if use_predefined_f0_limits == 0
    f0 = get_pitch(s,fs,shift);
else
    f0 = get_pitch(s,fs,shift,fmin,fmax);
end

% Plot F0
figure(1)
subplot(2,1,1)
plot(f0)
xlim([1 length(f0)])
subplot(2,1,2)
plot(s)
xlim([1 length(s)])







