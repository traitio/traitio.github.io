function [par_stat,pul_stat] = eval_stats(par,pul,fs)
%EVAL_STATS
%   [PAR_STATS,PUL_STATS] = EVAL_STATS(PAR,PUL,FS) evaluates statistics
%   (means and confidence intervals) of given speech and pulse parameters.
%
% Input:
%   par   - Structure consisting of extracted frame-based parameters:
%            par{1}   - Fundamental frequency
%            par{2}   - Voiced LSF spectrum
%            par{3}   - Unvoiced LSF spectrum
%            par{4}   - Vocal tract LSF spectrum
%            par{5}   - Voice source LSF spectrum
%            par{6}   - Speech energy
%            par{7}   - Harmonic-to-noise ratio (HNR)
%            par{8}   - H1-H2
%            par{9}   - Normalized amplitude quotient (NAQ)
%            par{12}  - FFT spectrum of voiced speech
%            par{13}  - FFT spectrum of unvoiced speech
%            par{14}  - FFT spectrum of voice source
%   pul   - Structure consisting of all individual glottal flow pulses and
%           their corresponding parameters:
%                pul{1}    - All extracted pulses (cell)
%                pul{2}    - Normalized pulses
%
% Output:
%   par_stat   - Structure consisting frame-based statistics:
%                par_stat{1}   - Mean and CI of F0
%                par_stat{2}   - Mean and CI of voiced speech LSF spectrum
%                par_stat{3}   - Mean and CI of unvoiced speech LSF spectrum
%                par_stat{4}   - Mean and CI of vocal tract LSF spectrum
%                par_stat{5}   - Mean and CI of voice source LSF spectrum
%                par_stat{6}   - Mean and CI of speech energy
%                par_stat{7}   - Mean and CI of HNR
%                par_stat{8}   - Mean and CI of H1-H2
%                par_stat{9}   - Mean and CI of NAQ
%                par_stat{12}  - Mean and CI of FFT spectrum of voiced speech
%                par_stat{13}  - Mean and CI of FFT spectrum of unvoiced speech
%                par_stat{14}  - Mean and CI of FFT spectrum of voice source
%
%   pul_stat - Structure consisting of pulse parameter statistics:
%                pul_stat      - Mean and CI of normalized pulses
%
% Tuomo Raitio
% 24.7.2012

disp('Evaluating statistics...');

% Parameters
alpha = 0.05;
f0 = par{1};

% LSF spectra
for type = 2:5
    lsf = par{type};
    [m,~,ci,~] = normfit(lsf,alpha);
    par_stat{type} = [m ; ci];
end

% FFT spectra
for type = [12 13 14];
    p = par{type};
    [m,~,ci,~] = normfit(p,alpha);
    par_stat{type} = [m ; ci];
end

% Evaluate speech parameters
for type = [1 6 7 8 9];
    p = par{type};
    p = p(f0 > 0,:);
    [m,~,ci,~] = normfit(p,alpha);
    par_stat{type} = [m ; ci];
end

% Evaluate pulse parameters
pulses = pul{2};
[m,~,ci,~] = normfit(pulses,alpha);
pul_stat = [m ; ci];

