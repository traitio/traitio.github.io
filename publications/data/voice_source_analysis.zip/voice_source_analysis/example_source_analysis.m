% Example on using voice source analysis.
%
% Required files
%
% - get_source.m      (main file for voice source analysis)
% - get_pitch.m       (pitch detection)
% - f0det.m           (pitch detection)
% - iaif.m            (glottal inverse filtering)
% - get_gci.m         (glottal closure detection)
% - eval_stats.m      (evaluation of parameter statistics)
% - plot_stats.m      (plotting parameter statistics)
%
% Tuomo Raitio
% 12.8.2012

function example_voice_source_analysis()

clc
clear
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Speech file
speechfile = 'mv_0002.wav';

% Settings
shift = 10;      % Frame shift
plot_ci = 0;     % Plot confidence intervals

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Read speech file
[s,fs] = wavread(speechfile);

% Analyse speech signal
[par,exc,pul] = get_source(s,fs,shift);

% Evaluate statistics
[par_stat,pul_stat] = eval_stats(par,pul,fs);

% Plot statistics
plot_stats(s,exc,fs,par,pul,par_stat,pul_stat,plot_ci)



