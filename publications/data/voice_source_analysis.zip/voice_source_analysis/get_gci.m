function gci = get_gci(dg,f0,fs)
%GET_GCI
%   GCI = GET_GCI(DG,F0,FS) estimates glottal closure instants (GCIs) by
%   finding minimum peaks from the glottal flow derivative.
%
%   dg   - Glottal flow derivative (one frame)
%   f0   - Current f0 value
%   fs   - Sampling frequency
%
%   gci  - GCI index vector
%
% Reference:
%
% T. Raitio, A. Suni, H. Pulakka, M. Vainio, and P. Alku, "Utilizing
% Glottal Source Pulse Library for Generating Improved Excitation Signal
% for HMM-Based Speech Synthesis", in IEEE International Conference on
% Acoustics, Speech and Signal Processing (ICASSP), 2011, pp. 4564-4567.
%
% Tuomo Raitio
% 10.7.2012

% Parameters
t0 = round(fs/f0);
ss = round(20/16000*fs);

% Find minimum in the center of the frame
dgc = dg;
dgc(1:round(length(dg)/4)) = 0;
dgc(round(3*length(dg)/4)) = 0;
minval = min(min(dgc));
minind = find(dgc == minval);
minind_orig = minind(1);

% Find GCIs backwards from minimum
stop_flag = 1;
t0b = minind_orig;
ind = 2;
while(stop_flag)
    if t0b(ind-1) - t0 < 1
        stop_flag = 0;
        break
    end
    t0b(ind) = t0b(ind-1) - t0;
    minval = 10;
    for i = t0b(ind)-ss:t0b(ind)+ss
        if i < 1 || i > length(dg)
            stop_flag = 0;
            break
        end
        if dg(i) < minval
            minval = dg(i);
            minind = i;
        end
    end
    t0b(ind) = minind;
    ind = ind + 1;
end

% Find GCIs forward from minimum
stop_flag = 1;
t0f = minind_orig;
ind = 2;
while(stop_flag)
    if t0f(ind-1) + t0 > length(dg)
        stop_flag = 0;
        break
    end
    t0f(ind) = t0f(ind-1) + t0;
    minval = 10;
    for i = t0f(ind)-ss:t0f(ind)+ss
        if i < 1 || i > length(dg)
            stop_flag = 0;
            break
        end
        if dg(i) < minval
            minval = dg(i);
            minind = i;
        end
    end
    t0f(ind) = minind;
    ind = ind + 1;
end

% Sort GCIs
gci = sort(unique([t0b t0f]));

