function [par,exc,pul] = get_source(s,fs,shift,fmin,fmax,win)
%GET_SOURCE
%   [PAR,EXC,PUL] = GET_SOURCE(S,FS)
%   This function estimates fundamental frequency and voiced/unvoiced
%   decision and applies glottal inverse filtering for the voice parts
%   separate the voice source and the vocal tract filter. Then several
%   voice source features are extracted, including individual glottal
%   flow pulses.
%
% Full syntax:
%   [PAR,EXC,PUL] = GET_SOURCE(S,FS,FMIN,FMAX,SHIFT,WIN)
%
% Input:
%   s      - Speech signal
%   fs     - Sampling frequency
%
% Optional input:
%   shift  - Frame shift (ms)
%   fmin   - Minimum F0 in Hz
%   fmax   - Maximum F0 in Hz
%   win    - Window size (ms)
%
% Output:
%   par    - Structure consisting of extracted frame-based parameters:
%            par{1}   - Fundamental frequency
%            par{2}   - Voiced LSF spectrum
%            par{3}   - Unvoiced LSF spectrum
%            par{4}   - Vocal tract LSF spectrum
%            par{5}   - Voice source LSF spectrum
%            par{6}   - Speech energy
%            par{7}   - Harmonic-to-noise ratio (HNR)
%            par{8}   - H1-H2
%            par{9}   - Normalized amplitude quotient (NAQ)
%            par{12}  - FFT spectrum of voiced speech
%            par{13}  - FFT spectrum of unvoiced speech
%            par{14}  - FFT spectrum of voice source
%
%   exc    - Estimated voice source signal
%   pul    - Structure consisting of all individual glottal flow pulses:
%            pul{1}    - All extracted pulses (cell)
%            pul{2}    - Normalized pulses
%
% References:
%
% T. Raitio, A. Suni, H. Pulakka, M. Vainio, and P. Alku, "Utilizing
% Glottal Source Pulse Library for Generating Improved Excitation Signal
% for HMM-Based Speech Synthesis", in IEEE International Conference on
% Acoustics, Speech and Signal Processing (ICASSP), 2011, pp. 4564-4567.
%
% T. Raitio, A. Suni, J. Yamagishi, H. Pulakka, J. Nurminen, M. Vainio,
% and P. Alku, "HMM-Based Speech Synthesis Utilizing Glottal Inverse
% Filtering", in IEEE Transactions on Audio, Speech, and Language
% Processing, vol. 19, no. 1, pp. 153-165, 2011.
%
% Tuomo Raitio
% 18.7.2012


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize

% Comments 
comments = 1;

% Disp
if comments == 1
    disp(['Get source:' char(10)])
end

% Set default parameters
if nargin < 2
    disp('Error: Too few parameters.');
    return;
end
if nargin < 3
    shift = 10;
end

% Check vector orientation
if size(s,2) > 1
    s = s';
end

% Glottal inverse filtering options
p_vt = round(fs/1000+4);    % LPC analysis order
p_gl = round(fs/2000);      % LPC analysis order for the glottal source

% High-pass filter options
Fstop = 40;                 % Stopband Frequency
Fpass = 70;                 % Passband Frequency
Nfir = round(300/16000*fs); % FIR numerator order

% Parameters
hnr_channels = 5;
nfft = 1024;
nformants = 10;

% Pulse extract parameters
maxpulselendiff = 0.05;
nplen = 10/1000*fs;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% F0 tracking and polarity detection
if nargin < 4
    [f0,pol] = get_pitch(s,fs,shift);
elseif nargin < 5
    [f0,pol] = get_pitch(s,fs,shift,fmin);
else
    [f0,pol] = get_pitch(s,fs,shift,fmin,fmax);
end

% Set polarity
s = pol*s;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preprocessing

% High-pass filter speech in order to remove possible low frequency
% fluctuations. As this is done here, there is no need to apply filtering
% inside the IAIF method. In case of linear phase FIR filter, signal is
% shifted to compensate the delay due to high-pass filtering.
if mod(Nfir,2) == 1
    Nfir = Nfir + 1;
end
B = hpfilter_fir(Fstop,Fpass,fs,Nfir);
s = [s ; zeros(round(length(B)/2)-1,1)];
s = filter(B,1,s);
s = s(round(length(B)/2):end);

% Evaluate the number of samples for window and shift
if nargin < 4
    fmin = min(f0(f0 > 0));
    if isempty(fmin) || isnan(fmin)
        fmin = 50;
    end
end
if nargin < 6
    win = 3/fmin*1000;
end
N = round(win/1000*fs);
Nshift = round(shift/1000*fs);
nf0 = ceil(length(s)/Nshift)+1;

% Zero-padding for estimating the beginning and the end
ns = round(N/2);
ne = ceil(length(s)/Nshift)*Nshift-length(s) + ns;
s = [zeros(ns,1) ; s ; zeros(ne,1)];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Apply glottal inverse filtering and extract vocal tract and glottal glow
% parameters
if comments == 1
    disp([char(10) 'Extracting glottal flow parameters...']);
end

% Initialize pulses
pind = 1;

% Initialize other parameters
sp = zeros(nf0,p_vt);
vt = zeros(nf0,p_vt);
gl = zeros(nf0,p_gl);
exc = zeros(size(s));
e = zeros(nf0,1);
naq = zeros(nf0,1);
hnr = zeros(nf0,hnr_channels);
h1h2 = zeros(nf0,1);
fft_sp = zeros(nf0,nfft/2);
fft_gl = zeros(nf0,nfft/2);
F = zeros(nf0,nformants);
pulses = {};
pulses_index = [];

% Estimate glottal source based on estimated F0
ind = 1;
while((ind-1)*Nshift+N <= length(s))

    % Get frame
    frame = s((ind-1)*Nshift+1:(ind-1)*Nshift+N);
    
    % Add noise to prevent problems with all-zero frames
    if sum(abs(frame)) == 0
        frame = 0.00001*(rand(size(frame))-0.5);
    end
    
    % Speech energy
    e(ind) = 10*log10(sum(frame.^2)/fs/N/10^(-12));

    % Overall spectrum of speech
    a = lpc(frame.*hanning(length(frame)),p_vt);
    sp(ind,:) = poly2lsf(a);
    tmp = db(abs(fft(frame.*hanning(length(frame)),nfft)));
    fft_sp(ind,:) = tmp(1:nfft/2);
    
    % Do not continue further if unvoiced
    if f0(ind) == 0
        ind = ind + 1;
        continue;
    end

    % Glottal inverse filtering using IAIF
    [g,a] = iaif(frame,fs,p_vt,p_gl,0.99,0);
    dg = filter([1 -1],1,g);
    
    % Save vocal tract and source spectrum
    vt(ind,:) = poly2lsf(a);
    ga = lpc(dg.*hanning(length(dg)),p_gl);
    gl(ind,:) = poly2lsf(ga);
    tmp = db(abs(fft(dg.*hanning(length(dg)),nfft)));
    fft_gl(ind,:) = tmp(1:nfft/2);
    
    % Harmonic analysis of the voice source
    [hnr(ind,:) h1h2(ind)] = harmonic_analysis(dg,f0(ind),fs,hnr_channels);
    
    % Get glottal closure instants
    gci = get_gci(dg,f0(ind),fs);

    % Extract two-period glottal flow segments
    naq_temp = 0;
    for i = 1:length(gci)-2
        
        % Get pulse
        p = dg(gci(i):gci(i+2));
        
        % Evaluate NAQ
        naq_temp(i) = evalNAQ(p);
        
        % Save pulse if its length is close to 2*t0
        if abs(length(p)-2*fs/f0(ind))/(2*fs/f0(ind)) < maxpulselendiff
            pulses{pind} = p;
            pulses_index(pind) = (ind-1)*Nshift + gci(i);
            pind = pind + 1;
        end
    end
    
    % Average framewise NAQ
    naq(ind) = mean(naq_temp);

    % Ovelap-add glottal source
    exc((ind-1)*Nshift+1:(ind-1)*Nshift+N) = ...
        exc((ind-1)*Nshift+1:(ind-1)*Nshift+N) + dg.*hanning(N);

    % Increment index
    ind = ind + 1;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Postprocessing

% Remove zero-padding from source
exc = exc(ns+1:end-ne);

% Post-process NAQ
naq = postprocess_naq(naq,f0);

% Window pulses, normalize npulses in length and energy
npulses = zeros(length(pulses),nplen);
for i = 1:length(pulses)
    pulses{i} = pulses{i}.*hanning(length(pulses{i}));
    p = pulses{i};
    npulses(i,:) = interp1(1:length(p),p,linspace(1,length(p),nplen),'cspline');
    npulses(i,:) = npulses(i,:)/sqrt(sum(npulses(i,:).^2));
end

% Select only unique pulses
if ~isempty(pulses_index)
    idx = pulses_index;
    idx_s = sort(idx);
    global_mean = mean(npulses,1);
    pind = 1;
    i = 1;
    while i <= length(idx)
        cur_index = idx_s(i);
        start = i;
        while i < length(idx) && abs(cur_index-idx_s(i+1)) < 10
            i = i + 1;
        end
        if i-start+1 == 1
            pulses_uniq{pind} = pulses{start};
            npulses_uniq(pind,:) = npulses(start:i,:);
        elseif i-start+1 == 2
            err = sum(abs(npulses(start:i,:) - repmat(global_mean,i-start+1,1)),2);
            minind = find(err == min(err));
            pulses_uniq{pind} = pulses{start+minind-1};
            npulses_uniq(pind,:) = npulses(start+minind-1,:);
        else
            pulse_mean = mean(npulses(start:i,:),1);
            err = sum(abs(npulses(start:i,:) - repmat(pulse_mean,i-start+1,1)),2);
            minind = find(err == min(err));
            pulses_uniq{pind} = pulses{start+minind-1};
            npulses_uniq(pind,:) = npulses(start+minind-1,:);
        end
        pind = pind + 1;
        i = i + 1;
    end
    pulses = pulses_uniq;
    npulses = npulses_uniq;
end

% Evaluate voiced/unvoiced LSF spectra
lsf_v = sp(f0 > 0,:);
lsf_uv = sp(f0 == 0,:);
p1 = {lsf_v,lsf_uv};
for i = 1:length(p1)
    lsf = p1{i};
    N = size(lsf,1);
    lsfs = zeros(N,nfft);
    for j = 1:N
        a = lsf2poly(lsf(j,:));
        h = freqz(1,a,nfft,fs);
        lsfs(j,:) = db(h);
    end
    p1{i} = lsfs;
end

% Evaluate VT/GL spectra
p2 = {vt,gl};
for i = 1:length(p2)
    lsf = p2{i};
    lsf = lsf(f0 > 0,:);
    N = size(lsf,1);
    lsfs = zeros(N,nfft);
    for j = 1:N
        a = lsf2poly(lsf(j,:));
        h = freqz(1,a,nfft,fs);
        lsfs(j,:) = db(h);
    end
    p2{i} = lsfs;
end

% Separate voiced/unvoiced FFT spectra
fft_v = fft_sp(f0 > 0,:);
fft_uv = fft_sp(f0 == 0,:);

% Create parameter structure
par{1} = f0';
par{2} = p1{1};
par{3} = p1{2};
par{4} = p2{1};
par{5} = p2{2};
par{6} = e;
par{7} = hnr;
par{8} = h1h2;
par{9} = naq;
par{12} = fft_v;
par{13} = fft_uv;
par{14} = fft_gl;

% Create pulse structure
pul{1} = pulses;
pul{2} = npulses;













% Harmonic analysis: Harmonic-to-noise ratio (HNR) and the difference
% between first and second harmonics (H1-H2).
function [hnr,h1h2] = harmonic_analysis(g,f0,fs,hnr_channels)

% Internal parameters
nfft = 4*1024;
hsc = 0.5;

% FFT
G = db(abs(fft(g.*hanning(length(g)),nfft)));
G = G(1:round(length(G)/2));

% Peak picking of harmonics
ind = 1;
maxind = f0/(fs/nfft)+1;
while(1)
    guess_index = round(ind*mean(maxind./(1:length(maxind))));
    hsr = round(max(hsc*f0/(fs/nfft)*((nfft/2-guess_index)/(nfft/2)),1));
    if guess_index+hsr > length(G)
        break
    end
    s = G(guess_index-hsr:guess_index+hsr);
    maxind(ind) = round(guess_index + find(s == max(s)) - hsr - 1);
    ind = ind + 1;
end

% Estimate interharmonic valleys
for i = 1:length(maxind)-1
    minind(i) = round((maxind(i+1)+maxind(i))/2);
end
maxind = maxind(1:length(minind));

% Evaluate difference
hnr = medfilt1(G(maxind)-G(minind),3);

% Convert to ERB
n = length(hnr);
erbinds = floor(log10(0.00437*((0:n)/(n)*(fs/2))+1)/log10(0.00437*(fs/2)+1)*(hnr_channels-0.00001))+1;
hnr_erb = zeros(1,hnr_channels);
hnr_sum = zeros(1,hnr_channels);
for i = 1:n
    hnr_erb(erbinds(i)) = hnr_erb(erbinds(i)) + hnr(i);
    hnr_sum(erbinds(i)) = hnr_sum(erbinds(i)) + 1;
end
hnr = hnr_erb./hnr_sum;
hnr(isnan(hnr)) = 0;
hnr(isinf(hnr)) = 0;

% H1-H2
h1h2 = G(maxind(1))-G(maxind(2));










% Evaluate normalized amplitude quotient (NAQ) of a two-period glottal
% flow derivative signal.
function naq = evalNAQ(p)
dpulse = p(round(length(p)/4):round(length(p)*3/4));
ipulse = filter(1,[1 -0.99],p);
dpeak = max(dpulse);
fac = max(ipulse);
naq = abs(fac(1)/dpeak(1))/(length(p)/2);








% Post-processing of NAQ by filling the gaps with nearest values and using
% 5-point median filtering.
function naq = postprocess_naq(naq,f0)
for i = 1:length(naq)
    if f0(i) > 0 && naq(i) == 0
        stop = 0;
        for j = 1:length(naq)
            
            % Backward
            k = i-j;
            if k >= 1
                if f0(k) > 0 && naq(k) > 0
                    naq(i) = naq(k);
                end
            end
            
            % Forward
            k = i+j;
            if k <= length(naq)
                if f0(k) > 0 && naq(k) > 0
                    naq(i) = naq(k);
                    stop = 1;
                end
            end
            
            % Stop
            if stop == 1
                break
            end
        end
    end
end
naq = medfilt1(naq,5);







function B = hpfilter_fir(Fstop,Fpass,fs,N)
% FIR least-squares Highpass filter design using the FIRLS function
%
% Tuomo Raitio
% 10.7.2012

% Calculate the coefficients using the FIRLS function.
b  = firls(N, [0 Fstop Fpass fs/2]/(fs/2), [0 0 1 1], [1 1]);
Hd = dfilt.dffir(b);

% Save to B
B = Hd.Numerator;


