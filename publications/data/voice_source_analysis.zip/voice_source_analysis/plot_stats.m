function plot_stats(s,exc,fs,par,pul,par_stat,pul_stat,plot_ci)
%PLOT_STATS
%   PLOT_STATS(S,EXC,FS,PAR,PUL,PAR_STAT,PUL_STAT,PLOT_CI) plots speech and
%   source signals and speech and voice source parameter statistics.

% Colors
colors = {'b','r','k','g'};

% Plot signal, source and F0
scrsz = get(0,'ScreenSize');
figure('Position',[scrsz(3)/4 scrsz(4)/4 1000 800])
f0 = par{1};
sh(1) = subplot(3,1,1);
plot(s)
title('Speech signal')
ylabel('Amplitude')
xlabel('Time (s)')
axis([1 length(s) min(s)-0.1 max(s)+0.1])
if length(s)/fs > 1.5
    t = fs;
else
    t = fs/10;
end
set(gca,'XTick',0:t:length(s))
set(gca,'XTickLabel',(0:t:length(s))/fs)
sh(2) = subplot(3,1,2);
plot(exc)
title('Voice source signal')
ylabel('Amplitude')
xlabel('Time (s)')
axis([1 length(exc) min(exc)-0.1 max(exc)+0.1])
set(gca,'XTick',0:t:length(s))
set(gca,'XTickLabel',(0:t:length(s))/fs)
sh(3) = subplot(3,1,3);
f0i = interp1(1:length(f0),f0,linspace(1,length(f0),length(s)),'cspline');
plot(f0i)
title('F0 (interpolated to signal length)')
ylabel('Frequency (Hz)')
xlabel('Time (s)')
axis([1 length(f0i) 0 max(f0i)+30])
set(gca,'XTick',0:t:length(s))
set(gca,'XTickLabel',(0:t:length(s))/fs)
linkaxes(sh,'x');

% Waveform resampled to constant length
figure(2)
p = pul_stat;
if plot_ci == 0
    plot(p(1,:),colors{1})
    hold on
else
    ciplot(p(2,:),p(3,:),1:length(p),colors{1},colors{1})
end
title('Average Glottal Flow Derivative Waveform')
ylabel('Amplitude')
xlabel('Time (samples)')
axis([1 length(p) min(min(p))-0.05 max(max(p))+0.05]);

% Display single number features
pars = {par_stat{1},par_stat{6},par_stat{8},par_stat{9}};
names = {'F0:   ','Gain: ','H1-H2:','NAQ:  '};
acc = {'%1.1f','%1.1f','%1.1f','%1.4f'};
disp([char(10) 'Means and 95 percent confidence intervals:' char(10)])
for v = 1:length(pars)
    disp([names{v} '  Mean      CI']);
    space = repmat(' ',1,10-length(num2str(pars{v}(1),acc{v})));
    disp(['        ' num2str(pars{v}(1),acc{v}) space '[' num2str(pars{v}(2),acc{v}) '  ' num2str(pars{v}(3),acc{v}) ']'])
    disp(' ')
end

% HNR
figure(3)
p = par_stat{7};
plot(p(1,:),[colors{1} 'd--'])
hold on
errorbar(1:length(p),p(1,:),p(1,:)-p(2,:),p(3,:)-p(1,:))
title('Average Harmonic-To-Noise Ratio (HNR)')
ylabel('Magnitude (dB)')
xlabel('ERB Band')
axis([0.5 size(p,2)+0.5 min(min(p))-5 max(max(p))+10]);
set(gca,'XTick',1:size(p,2));
set(gca,'XTickLabel',1:size(p,2))

% Spectra
figure(4)
type = 2:5;
for i = 1:length(type)
    p = par_stat{type(i)};
    w = linspace(0,fs/2,length(p));
    if plot_ci == 0
        plot(w,p(1,:),colors{i})
        hold on
    else
        if size(p,2) == length(w)
            ciplot(p(2,:),p(3,:),w,colors{i},colors{i})
        end
        hold on
    end
    minval(i) = min(min(p));
    maxval(i) = max(max(p));
end
legend('Voiced','Unvoiced','Vocal tract','Voice Source')
title('Average LPC Spectrum')
ylabel('Magnitude (dB)')
xlabel('Frequency (Hz)')
axis([0 fs/2 min(minval)-5 max(maxval)+5]);

% FFT Spectra
figure(5)
type = [12 13 14];
for i = 1:length(type)
    p = par_stat{type(i)};
    w = linspace(0,fs/2,length(p));
    if plot_ci == 0
        plot(w,p(1,:),colors{i})
        hold on
    else
        if size(p,2) == length(w)
            ciplot(p(2,:),p(3,:),w,colors{i},colors{i})
        end
        hold on
    end
    minval(i) = min(min(p));
    maxval(i) = max(max(p));
end
legend('Voiced','Unvoiced','Source')
title('Average FFT Spectrum')
ylabel('Magnitude (dB)')
xlabel('Frequency (Hz)')
axis([0 fs/2 min(minval)-5 max(maxval)+5]);






 